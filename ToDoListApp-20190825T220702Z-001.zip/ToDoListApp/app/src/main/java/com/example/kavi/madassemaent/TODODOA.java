package com.example.kavi.madassemaent;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.ContextThemeWrapper;

import java.util.ArrayList;
import java.util.List;

public class TODODOA {

    private SQLiteDatabase db;

    private DataBase dbHelper;


public TODODOA(Context context){
    dbHelper = new DataBase(context);
    db = dbHelper.getWritableDatabase();
}
//close the db
    public void close(){
    db.close();
    }

    public void createtTODO (String todoText){
        ContentValues contentValues = new ContentValues();
        contentValues.put("todo",todoText);

        //insert into db
        db.insert("todo",null,contentValues);
    }

    public void  deleteTODO(int todoId){
        db.delete("todo","_id ="+todoId,null);
    }

    public List<TODO> getTodo(){
        List<TODO> todoList = new ArrayList<TODO>();
        String[] tableColumns = new  String[] {"_id","todo"};
        Cursor cursor = db.query("todo", tableColumns,null,null,null,null,null);
        cursor.moveToFirst();


        while (!cursor.isAfterLast()){
            TODO todo = new  TODO();
            todo.setId(cursor.getInt(0));
            todo.setText(cursor.getString(1));


            todoList.add(todo);

            cursor.moveToNext();
        }
       return  todoList ;
    }

}

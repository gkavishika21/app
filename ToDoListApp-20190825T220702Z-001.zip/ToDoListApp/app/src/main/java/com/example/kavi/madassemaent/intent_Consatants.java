package com.example.kavi.madassemaent;

public class intent_Consatants {

    public final static int INTENT_REQUEST_CODE=1;
    public final static int INTENT_RESULT_CODE=1;
    public final static int INTENT_REQUEST_CODE_TWO=2;
    public final static int INTENT_RESULT_CODE_TWO=2;
    public final static String INTENT_MESSAGE_FIELD="Message_field";
    public final static String INTENT_MESSAGE_DATA="Message_data";
    public final static String INTENT_ITEM_POSITION="Item_position";
    public final static String INTENT_CHANGED_MESSAGE="changed_message";


}
